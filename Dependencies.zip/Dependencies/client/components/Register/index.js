import Register from './Register'
import RegisterSuccess from './RegisterSuccess'

export default {
	Register,
	RegisterSuccess
}

export {
	Register,
	RegisterSuccess
}