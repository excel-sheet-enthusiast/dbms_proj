import ErrorContent from './ErrorContent'

export default ErrorContent